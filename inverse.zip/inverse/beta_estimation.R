estimate_beta <- function(app, opt){
  ratio = app/opt
  beta  = -1*log(1 - ratio)
  return(mean(beta))
}
factor <- (1-(1/exp(1)))
ltm <- scan('tileminer_mushrooms_coverage')
opt <- ltm/factor
alpha04 <- scan('coverage_sampling_mushrooms')
alpha03 <- scan('rev1_cov_0.3')
alpha02 <- scan('rev1_cov_0.2')
alpha01 <- scan('rev1_cov_0.1')



beta <- c(estimate_beta(alpha01,opt),estimate_beta(alpha02,opt),estimate_beta(alpha03,opt),estimate_beta(alpha04,opt))

alpha <- c(0.1,0.2,0.3,0.4)

print(lm(beta ~ alpha -1))

