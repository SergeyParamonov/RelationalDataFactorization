library(latex2exp)

draw <- function(x, name, color){
  data = scan(name)
  points(x, data, col=color)
  lo <- loess(data~x)
  lines(predict(lo), col=color, lwd=1)
}


pdf("tiling_comparison.pdf")
x <- 1:20
ltm      <- scan("tileminer_mushrooms_coverage")
tiling   <- scan("tile_coverage_muschroom")
sampling <- scan("coverage_sampling_mushrooms")

plot(x, ltm, col="blue", xlab="Number of tiles", ylab="Coverage measure",  ylim=c(0,0.8), xlim=c(1,20), xaxt='n')
lo <- loess(ltm~x)
lines(predict(lo), col='blue', lwd=1)

sampling_03_color = "darkmagenta"
sampling_02_color = "gold"
sampling_01_color = "black"

legend("topleft", 
       legend=c("LTM-k","Plain Encoding",expression(paste("Sampling ",alpha,"=0.4")),expression(paste("Sampling ",alpha,"=0.3")),expression(paste("Sampling ",alpha,"=0.2")),expression(paste("Sampling ",alpha,"=0.1"))), 
       col=c("blue","red", "green", sampling_03_color, sampling_02_color ,sampling_01_color),
       lty=1)

axis(2, at =c(0.1,0.3,0.5,0.7))
#axis(1, at =c(1,3,5,7,9,11,13,15,17,19))
points(x, sampling, col="green")
lo <- loess(sampling~x)
lines(predict(lo), col='green', lwd=1)

#only 10 points available
x <- 1:10
points(x, tiling, col="red")
lo <- loess(tiling~x)
lines(predict(lo), col='red', lwd=1)
x<-1:20
draw(x, "rev1_cov_0.1", sampling_01_color)
draw(x, "rev1_cov_0.2", sampling_02_color)
draw(x, "rev1_cov_0.3", sampling_03_color)
dev.off()
