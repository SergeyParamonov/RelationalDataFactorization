draw <- function(x, name, color){
  data = scan(name)
  points(x, data, col=color)
  lo <- loess(data~x)
  lines(predict(lo), col=color, lwd=1)
}


pdf("tiling-time-plot.pdf")
#total time
ltm      <- scan("tileminer_mushrooms_hours")
#time for i-th iteration
timePerTile <- scan("muschroom_time_pure")
#time for i-th iteraton
samplingTimePerTile <- scan("sampling_time_mushrooms")

encoding <- vector()
for(i in 1:10){
  encoding[i] <- sum(timePerTile[1:i])
}
sampling <- vector()
for(i in 1:20){
  sampling[i] <- sum(samplingTimePerTile[1:i])
}

x <- 1:10
plot(x, encoding, col="red", xlab="Number of tiles", ylab="Runtime in hours", ylim=c(0,20), xlim=c(1,20))
lo <- loess(encoding~x)
lines(predict(lo), col='red', lwd=1)

sampling_03_color = "darkmagenta"
sampling_02_color = "gold"
sampling_01_color = "black"

legend("topright", 
       legend=c("LTM-k","Plain Encoding",expression(paste("Sampling ",alpha,"=0.4")),expression(paste("Sampling ",alpha,"=0.3")),expression(paste("Sampling ",alpha,"=0.2")),expression(paste("Sampling ",alpha,"=0.1"))), 
       col=c("blue","red", "green", sampling_03_color, sampling_02_color ,sampling_01_color),
       lty=1)


x <- 1:20

points(x, ltm, col="blue")
lo <- loess(ltm~x)
lines(predict(lo), col='blue', lwd=1)

points(x, sampling, col="green")
lo <- loess(sampling~x)
lines(predict(lo), col='green', lwd=1)

draw(x, "runtime_sum_rev1_0.1", sampling_01_color)
draw(x, "runtime_sum_rev1_0.2", sampling_02_color)
draw(x, "runtime_sum_rev1_0.3", sampling_03_color)

dev.off()


